<?php 
if (isset($_GET['subject'])) {$subject=$_GET['subject'];}
 else {$subject="anonymous";}
if (isset($_GET['condnum'])) {$condnum=$_GET['condnum'];}
	else {$condnum=-1;}?><HTML>
<HEAD>
<TITLE>MouselabWEB Survey</TITLE>
<script language=javascript src="mlweb.js"></SCRIPT>
<link rel="stylesheet" href="mlweb.css" type="text/css">
</head>

<body onLoad="timefunction('onload','body','body')">
<script language="javascript">
ref_cur_hit = <?php echo($condnum);?>;
subject = "<?php echo($subject);?>";
</script>

<!--BEGIN TABLE STRUCTURE-->
<SCRIPT language="javascript">
//override defaults
mlweb_outtype="CSV";
mlweb_fname="mlwebform";
tag = "m0^m1^m2^m3`"
 + "s0^s1^s2^s3`"
 + "k0^k1^k2^k3`"
 + "n0^n1^n2^n3";

txt = "Lebkuchen- gewürz & Gewürze (Zimt, Kardamom, Nelken)^Zartbitter- schokolade & Walnüsse^Haselnüsse & Konfitüre^Mohn `"
 + "200 g Zucker + Vanillezucker ^150 g Zucker + 0,5g Kräuter ^80 g Zucker^90 g Xylith`"
 + "120^110^130^105`"
 + "Bunte Mürbeteig Kekse^Brownie-Weihnachtsplätzchen^Caros Doppeldecker^Mohn-Spritzgebäck";

state = "1^1^1^1`"
 + "1^1^1^1`"
 + "1^1^1^1`"
 + "1^1^1^1";

box = "Besondere Zutat^Besondere Zutat^Besondere Zutat^Besondere Zutat`"
 + "Süße^Süße^Süße^Süße`"
 + "Kalorien pro Stück (ca.)^Kalorien pro Stück (ca.)^Kalorien pro Stück (ca.)^Kalorien pro Stück (ca.)`"
 + "Name^Name^Name^Name";

CBCol = "0^0^0^0";
CBRow = "1^1^1^0";
W_Col = "100^100^100^100";
H_Row = "150^150^150^150";

chkchoice = false;
btnFlg = 1;
btnType = "button";
btntxt = "Keks 1^Keks 2^Keks 3^Keks 4";
btnstate = "1^1^1^1";
btntag = "btn1^btn2^btn3^btn4";
to_email = "levin.bittner@uni-erfurt.de";
colFix = true;
rowFix = false;
CBpreset = false;
evtOpen = 0;
evtClose = 0;
chkFrm=false;
warningTxt = "Some questions have not been answered. Please answer all questions before continuing!";
tmTotalSec = 60;
tmStepSec = 1;
tmWidthPx = 200;
tmFill = true;
tmShowTime = true;
tmCurTime = 0;
tmActive = false;
tmDirectStart = true;
tmMinLabel = "min";
tmSecLabel = "sec";
tmLabel = "Timer: ";

//Delay: m0 m1 m2 m3 s0 s1 s2 s3 k0 k1 k2 k3 n0 n1 n2 n3
delay = "0^0^0^0^0^0^0^0^0^0^0^0^0^0^0^0`"
 + "0^0^0^0^0^0^0^0^0^0^0^0^0^0^0^0`"
 + "0^0^0^0^0^0^0^0^0^0^0^0^0^0^0^0`"
 + "0^0^0^0^0^0^0^0^0^0^0^0^0^0^0^0`"
 + "0^0^0^0^0^0^0^0^0^0^0^0^0^0^0^0`"
 + "0^0^0^0^0^0^0^0^0^0^0^0^0^0^0^0`"
 + "0^0^0^0^0^0^0^0^0^0^0^0^0^0^0^0`"
 + "0^0^0^0^0^0^0^0^0^0^0^0^0^0^0^0`"
 + "0^0^0^0^0^0^0^0^0^0^0^0^0^0^0^0`"
 + "0^0^0^0^0^0^0^0^0^0^0^0^0^0^0^0`"
 + "0^0^0^0^0^0^0^0^0^0^0^0^0^0^0^0`"
 + "0^0^0^0^0^0^0^0^0^0^0^0^0^0^0^0`"
 + "0^0^0^0^0^0^0^0^0^0^0^0^0^0^0^0`"
 + "0^0^0^0^0^0^0^0^0^0^0^0^0^0^0^0`"
 + "0^0^0^0^0^0^0^0^0^0^0^0^0^0^0^0`"
 + "0^0^0^0^0^0^0^0^0^0^0^0^0^0^0^0";
activeClass = "actTD";
inactiveClass = "inactTD";
boxClass = "boxTD";
cssname = "mlweb.css";
nextURL = "thanks.html";
expname = "Keks";
randomOrder = false;
recOpenCells = false;
masterCond = 1;
loadMatrices();
</SCRIPT>
<!--END TABLE STRUCTURE-->

<FORM name="mlwebform" onSubmit="return checkForm(this)" method="POST" action="save.php"><INPUT type=hidden name="procdata" value="">
<input type=hidden name="subject" value="">
<input type=hidden name="expname" value="">
<input type=hidden name="nextURL" value="">
<input type=hidden name="choice" value="">
<input type=hidden name="condnum" value="">
<input type=hidden name="to_email" value="">
<!--BEGIN preHTML-->

<!--END preHTML-->
<!-- MOUSELAB TABLE -->
<TABLE border=1>
<TR>
<!--cell a0(tag:m0)-->
<TD align=center valign=middle><DIV ID="a0_cont" style="position: relative; height: 150px; width: 100px;"><DIV ID="a0_txt" STYLE="position: absolute; left: 0px; top: 0px; height: 150px; width: 100px; clip: rect(0px 100px 150px 0px); z-index: 1;"><TABLE><TD ID="a0_td" align=center valign=center width=95 height=145 class="actTD">Lebkuchen- gewürz & Gewürze (Zimt, Kardamom, Nelken)</TD></TABLE></DIV><DIV ID="a0_box" STYLE="position: absolute; left: 0px; top: 0px; height: 150px; width: 100px; clip: rect(0px 100px 150px 0px); z-index: 2;"><TABLE><TD ID="a0_tdbox" align=center valign=center width=95 height=145 class="boxTD">Besondere Zutat</TD></TABLE></DIV><DIV ID="a0_img" STYLE="position: absolute; left: 0px; top: 0px; height: 150px; width: 100px; z-index: 5;"><A HREF="javascript:void(0);" NAME="a0" onMouseOver="ShowCont('a0',event)" onMouseOut="HideCont('a0',event)"><IMG NAME="a0" SRC="transp.gif" border=0 width=100 height=150></A></DIV></DIV></TD>
<!--end cell-->
<!--cell a1(tag:m1)-->
<TD align=center valign=middle><DIV ID="a1_cont" style="position: relative; height: 150px; width: 100px;"><DIV ID="a1_txt" STYLE="position: absolute; left: 0px; top: 0px; height: 150px; width: 100px; clip: rect(0px 100px 150px 0px); z-index: 1;"><TABLE><TD ID="a1_td" align=center valign=center width=95 height=145 class="actTD">Zartbitter- schokolade & Walnüsse</TD></TABLE></DIV><DIV ID="a1_box" STYLE="position: absolute; left: 0px; top: 0px; height: 150px; width: 100px; clip: rect(0px 100px 150px 0px); z-index: 2;"><TABLE><TD ID="a1_tdbox" align=center valign=center width=95 height=145 class="boxTD">Besondere Zutat</TD></TABLE></DIV><DIV ID="a1_img" STYLE="position: absolute; left: 0px; top: 0px; height: 150px; width: 100px; z-index: 5;"><A HREF="javascript:void(0);" NAME="a1" onMouseOver="ShowCont('a1',event)" onMouseOut="HideCont('a1',event)"><IMG NAME="a1" SRC="transp.gif" border=0 width=100 height=150></A></DIV></DIV></TD>
<!--end cell-->
<!--cell a2(tag:m2)-->
<TD align=center valign=middle><DIV ID="a2_cont" style="position: relative; height: 150px; width: 100px;"><DIV ID="a2_txt" STYLE="position: absolute; left: 0px; top: 0px; height: 150px; width: 100px; clip: rect(0px 100px 150px 0px); z-index: 1;"><TABLE><TD ID="a2_td" align=center valign=center width=95 height=145 class="actTD">Haselnüsse & Konfitüre</TD></TABLE></DIV><DIV ID="a2_box" STYLE="position: absolute; left: 0px; top: 0px; height: 150px; width: 100px; clip: rect(0px 100px 150px 0px); z-index: 2;"><TABLE><TD ID="a2_tdbox" align=center valign=center width=95 height=145 class="boxTD">Besondere Zutat</TD></TABLE></DIV><DIV ID="a2_img" STYLE="position: absolute; left: 0px; top: 0px; height: 150px; width: 100px; z-index: 5;"><A HREF="javascript:void(0);" NAME="a2" onMouseOver="ShowCont('a2',event)" onMouseOut="HideCont('a2',event)"><IMG NAME="a2" SRC="transp.gif" border=0 width=100 height=150></A></DIV></DIV></TD>
<!--end cell-->
<!--cell a3(tag:m3)-->
<TD align=center valign=middle><DIV ID="a3_cont" style="position: relative; height: 150px; width: 100px;"><DIV ID="a3_txt" STYLE="position: absolute; left: 0px; top: 0px; height: 150px; width: 100px; clip: rect(0px 100px 150px 0px); z-index: 1;"><TABLE><TD ID="a3_td" align=center valign=center width=95 height=145 class="actTD">Mohn </TD></TABLE></DIV><DIV ID="a3_box" STYLE="position: absolute; left: 0px; top: 0px; height: 150px; width: 100px; clip: rect(0px 100px 150px 0px); z-index: 2;"><TABLE><TD ID="a3_tdbox" align=center valign=center width=95 height=145 class="boxTD">Besondere Zutat</TD></TABLE></DIV><DIV ID="a3_img" STYLE="position: absolute; left: 0px; top: 0px; height: 150px; width: 100px; z-index: 5;"><A HREF="javascript:void(0);" NAME="a3" onMouseOver="ShowCont('a3',event)" onMouseOut="HideCont('a3',event)"><IMG NAME="a3" SRC="transp.gif" border=0 width=100 height=150></A></DIV></DIV></TD>
<!--end cell--></TR><TR>
<!--cell b0(tag:s0)-->
<TD align=center valign=middle><DIV ID="b0_cont" style="position: relative; height: 150px; width: 100px;"><DIV ID="b0_txt" STYLE="position: absolute; left: 0px; top: 0px; height: 150px; width: 100px; clip: rect(0px 100px 150px 0px); z-index: 1;"><TABLE><TD ID="b0_td" align=center valign=center width=95 height=145 class="actTD">200 g Zucker + Vanillezucker </TD></TABLE></DIV><DIV ID="b0_box" STYLE="position: absolute; left: 0px; top: 0px; height: 150px; width: 100px; clip: rect(0px 100px 150px 0px); z-index: 2;"><TABLE><TD ID="b0_tdbox" align=center valign=center width=95 height=145 class="boxTD">Süße</TD></TABLE></DIV><DIV ID="b0_img" STYLE="position: absolute; left: 0px; top: 0px; height: 150px; width: 100px; z-index: 5;"><A HREF="javascript:void(0);" NAME="b0" onMouseOver="ShowCont('b0',event)" onMouseOut="HideCont('b0',event)"><IMG NAME="b0" SRC="transp.gif" border=0 width=100 height=150></A></DIV></DIV></TD>
<!--end cell-->
<!--cell b1(tag:s1)-->
<TD align=center valign=middle><DIV ID="b1_cont" style="position: relative; height: 150px; width: 100px;"><DIV ID="b1_txt" STYLE="position: absolute; left: 0px; top: 0px; height: 150px; width: 100px; clip: rect(0px 100px 150px 0px); z-index: 1;"><TABLE><TD ID="b1_td" align=center valign=center width=95 height=145 class="actTD">150 g Zucker + 0,5g Kräuter </TD></TABLE></DIV><DIV ID="b1_box" STYLE="position: absolute; left: 0px; top: 0px; height: 150px; width: 100px; clip: rect(0px 100px 150px 0px); z-index: 2;"><TABLE><TD ID="b1_tdbox" align=center valign=center width=95 height=145 class="boxTD">Süße</TD></TABLE></DIV><DIV ID="b1_img" STYLE="position: absolute; left: 0px; top: 0px; height: 150px; width: 100px; z-index: 5;"><A HREF="javascript:void(0);" NAME="b1" onMouseOver="ShowCont('b1',event)" onMouseOut="HideCont('b1',event)"><IMG NAME="b1" SRC="transp.gif" border=0 width=100 height=150></A></DIV></DIV></TD>
<!--end cell-->
<!--cell b2(tag:s2)-->
<TD align=center valign=middle><DIV ID="b2_cont" style="position: relative; height: 150px; width: 100px;"><DIV ID="b2_txt" STYLE="position: absolute; left: 0px; top: 0px; height: 150px; width: 100px; clip: rect(0px 100px 150px 0px); z-index: 1;"><TABLE><TD ID="b2_td" align=center valign=center width=95 height=145 class="actTD">80 g Zucker</TD></TABLE></DIV><DIV ID="b2_box" STYLE="position: absolute; left: 0px; top: 0px; height: 150px; width: 100px; clip: rect(0px 100px 150px 0px); z-index: 2;"><TABLE><TD ID="b2_tdbox" align=center valign=center width=95 height=145 class="boxTD">Süße</TD></TABLE></DIV><DIV ID="b2_img" STYLE="position: absolute; left: 0px; top: 0px; height: 150px; width: 100px; z-index: 5;"><A HREF="javascript:void(0);" NAME="b2" onMouseOver="ShowCont('b2',event)" onMouseOut="HideCont('b2',event)"><IMG NAME="b2" SRC="transp.gif" border=0 width=100 height=150></A></DIV></DIV></TD>
<!--end cell-->
<!--cell b3(tag:s3)-->
<TD align=center valign=middle><DIV ID="b3_cont" style="position: relative; height: 150px; width: 100px;"><DIV ID="b3_txt" STYLE="position: absolute; left: 0px; top: 0px; height: 150px; width: 100px; clip: rect(0px 100px 150px 0px); z-index: 1;"><TABLE><TD ID="b3_td" align=center valign=center width=95 height=145 class="actTD">90 g Xylith</TD></TABLE></DIV><DIV ID="b3_box" STYLE="position: absolute; left: 0px; top: 0px; height: 150px; width: 100px; clip: rect(0px 100px 150px 0px); z-index: 2;"><TABLE><TD ID="b3_tdbox" align=center valign=center width=95 height=145 class="boxTD">Süße</TD></TABLE></DIV><DIV ID="b3_img" STYLE="position: absolute; left: 0px; top: 0px; height: 150px; width: 100px; z-index: 5;"><A HREF="javascript:void(0);" NAME="b3" onMouseOver="ShowCont('b3',event)" onMouseOut="HideCont('b3',event)"><IMG NAME="b3" SRC="transp.gif" border=0 width=100 height=150></A></DIV></DIV></TD>
<!--end cell--></TR><TR>
<!--cell c0(tag:k0)-->
<TD align=center valign=middle><DIV ID="c0_cont" style="position: relative; height: 150px; width: 100px;"><DIV ID="c0_txt" STYLE="position: absolute; left: 0px; top: 0px; height: 150px; width: 100px; clip: rect(0px 100px 150px 0px); z-index: 1;"><TABLE><TD ID="c0_td" align=center valign=center width=95 height=145 class="actTD">120</TD></TABLE></DIV><DIV ID="c0_box" STYLE="position: absolute; left: 0px; top: 0px; height: 150px; width: 100px; clip: rect(0px 100px 150px 0px); z-index: 2;"><TABLE><TD ID="c0_tdbox" align=center valign=center width=95 height=145 class="boxTD">Kalorien pro Stück (ca.)</TD></TABLE></DIV><DIV ID="c0_img" STYLE="position: absolute; left: 0px; top: 0px; height: 150px; width: 100px; z-index: 5;"><A HREF="javascript:void(0);" NAME="c0" onMouseOver="ShowCont('c0',event)" onMouseOut="HideCont('c0',event)"><IMG NAME="c0" SRC="transp.gif" border=0 width=100 height=150></A></DIV></DIV></TD>
<!--end cell-->
<!--cell c1(tag:k1)-->
<TD align=center valign=middle><DIV ID="c1_cont" style="position: relative; height: 150px; width: 100px;"><DIV ID="c1_txt" STYLE="position: absolute; left: 0px; top: 0px; height: 150px; width: 100px; clip: rect(0px 100px 150px 0px); z-index: 1;"><TABLE><TD ID="c1_td" align=center valign=center width=95 height=145 class="actTD">110</TD></TABLE></DIV><DIV ID="c1_box" STYLE="position: absolute; left: 0px; top: 0px; height: 150px; width: 100px; clip: rect(0px 100px 150px 0px); z-index: 2;"><TABLE><TD ID="c1_tdbox" align=center valign=center width=95 height=145 class="boxTD">Kalorien pro Stück (ca.)</TD></TABLE></DIV><DIV ID="c1_img" STYLE="position: absolute; left: 0px; top: 0px; height: 150px; width: 100px; z-index: 5;"><A HREF="javascript:void(0);" NAME="c1" onMouseOver="ShowCont('c1',event)" onMouseOut="HideCont('c1',event)"><IMG NAME="c1" SRC="transp.gif" border=0 width=100 height=150></A></DIV></DIV></TD>
<!--end cell-->
<!--cell c2(tag:k2)-->
<TD align=center valign=middle><DIV ID="c2_cont" style="position: relative; height: 150px; width: 100px;"><DIV ID="c2_txt" STYLE="position: absolute; left: 0px; top: 0px; height: 150px; width: 100px; clip: rect(0px 100px 150px 0px); z-index: 1;"><TABLE><TD ID="c2_td" align=center valign=center width=95 height=145 class="actTD">130</TD></TABLE></DIV><DIV ID="c2_box" STYLE="position: absolute; left: 0px; top: 0px; height: 150px; width: 100px; clip: rect(0px 100px 150px 0px); z-index: 2;"><TABLE><TD ID="c2_tdbox" align=center valign=center width=95 height=145 class="boxTD">Kalorien pro Stück (ca.)</TD></TABLE></DIV><DIV ID="c2_img" STYLE="position: absolute; left: 0px; top: 0px; height: 150px; width: 100px; z-index: 5;"><A HREF="javascript:void(0);" NAME="c2" onMouseOver="ShowCont('c2',event)" onMouseOut="HideCont('c2',event)"><IMG NAME="c2" SRC="transp.gif" border=0 width=100 height=150></A></DIV></DIV></TD>
<!--end cell-->
<!--cell c3(tag:k3)-->
<TD align=center valign=middle><DIV ID="c3_cont" style="position: relative; height: 150px; width: 100px;"><DIV ID="c3_txt" STYLE="position: absolute; left: 0px; top: 0px; height: 150px; width: 100px; clip: rect(0px 100px 150px 0px); z-index: 1;"><TABLE><TD ID="c3_td" align=center valign=center width=95 height=145 class="actTD">105</TD></TABLE></DIV><DIV ID="c3_box" STYLE="position: absolute; left: 0px; top: 0px; height: 150px; width: 100px; clip: rect(0px 100px 150px 0px); z-index: 2;"><TABLE><TD ID="c3_tdbox" align=center valign=center width=95 height=145 class="boxTD">Kalorien pro Stück (ca.)</TD></TABLE></DIV><DIV ID="c3_img" STYLE="position: absolute; left: 0px; top: 0px; height: 150px; width: 100px; z-index: 5;"><A HREF="javascript:void(0);" NAME="c3" onMouseOver="ShowCont('c3',event)" onMouseOut="HideCont('c3',event)"><IMG NAME="c3" SRC="transp.gif" border=0 width=100 height=150></A></DIV></DIV></TD>
<!--end cell--></TR><TR>
<!--cell d0(tag:n0)-->
<TD align=center valign=middle><DIV ID="d0_cont" style="position: relative; height: 150px; width: 100px;"><DIV ID="d0_txt" STYLE="position: absolute; left: 0px; top: 0px; height: 150px; width: 100px; clip: rect(0px 100px 150px 0px); z-index: 1;"><TABLE><TD ID="d0_td" align=center valign=center width=95 height=145 class="actTD">Bunte Mürbeteig Kekse</TD></TABLE></DIV><DIV ID="d0_box" STYLE="position: absolute; left: 0px; top: 0px; height: 150px; width: 100px; clip: rect(0px 100px 150px 0px); z-index: 2;"><TABLE><TD ID="d0_tdbox" align=center valign=center width=95 height=145 class="boxTD">Name</TD></TABLE></DIV><DIV ID="d0_img" STYLE="position: absolute; left: 0px; top: 0px; height: 150px; width: 100px; z-index: 5;"><A HREF="javascript:void(0);" NAME="d0" onMouseOver="ShowCont('d0',event)" onMouseOut="HideCont('d0',event)"><IMG NAME="d0" SRC="transp.gif" border=0 width=100 height=150></A></DIV></DIV></TD>
<!--end cell-->
<!--cell d1(tag:n1)-->
<TD align=center valign=middle><DIV ID="d1_cont" style="position: relative; height: 150px; width: 100px;"><DIV ID="d1_txt" STYLE="position: absolute; left: 0px; top: 0px; height: 150px; width: 100px; clip: rect(0px 100px 150px 0px); z-index: 1;"><TABLE><TD ID="d1_td" align=center valign=center width=95 height=145 class="actTD">Brownie-Weihnachtsplätzchen</TD></TABLE></DIV><DIV ID="d1_box" STYLE="position: absolute; left: 0px; top: 0px; height: 150px; width: 100px; clip: rect(0px 100px 150px 0px); z-index: 2;"><TABLE><TD ID="d1_tdbox" align=center valign=center width=95 height=145 class="boxTD">Name</TD></TABLE></DIV><DIV ID="d1_img" STYLE="position: absolute; left: 0px; top: 0px; height: 150px; width: 100px; z-index: 5;"><A HREF="javascript:void(0);" NAME="d1" onMouseOver="ShowCont('d1',event)" onMouseOut="HideCont('d1',event)"><IMG NAME="d1" SRC="transp.gif" border=0 width=100 height=150></A></DIV></DIV></TD>
<!--end cell-->
<!--cell d2(tag:n2)-->
<TD align=center valign=middle><DIV ID="d2_cont" style="position: relative; height: 150px; width: 100px;"><DIV ID="d2_txt" STYLE="position: absolute; left: 0px; top: 0px; height: 150px; width: 100px; clip: rect(0px 100px 150px 0px); z-index: 1;"><TABLE><TD ID="d2_td" align=center valign=center width=95 height=145 class="actTD">Caros Doppeldecker</TD></TABLE></DIV><DIV ID="d2_box" STYLE="position: absolute; left: 0px; top: 0px; height: 150px; width: 100px; clip: rect(0px 100px 150px 0px); z-index: 2;"><TABLE><TD ID="d2_tdbox" align=center valign=center width=95 height=145 class="boxTD">Name</TD></TABLE></DIV><DIV ID="d2_img" STYLE="position: absolute; left: 0px; top: 0px; height: 150px; width: 100px; z-index: 5;"><A HREF="javascript:void(0);" NAME="d2" onMouseOver="ShowCont('d2',event)" onMouseOut="HideCont('d2',event)"><IMG NAME="d2" SRC="transp.gif" border=0 width=100 height=150></A></DIV></DIV></TD>
<!--end cell-->
<!--cell d3(tag:n3)-->
<TD align=center valign=middle><DIV ID="d3_cont" style="position: relative; height: 150px; width: 100px;"><DIV ID="d3_txt" STYLE="position: absolute; left: 0px; top: 0px; height: 150px; width: 100px; clip: rect(0px 100px 150px 0px); z-index: 1;"><TABLE><TD ID="d3_td" align=center valign=center width=95 height=145 class="actTD">Mohn-Spritzgebäck</TD></TABLE></DIV><DIV ID="d3_box" STYLE="position: absolute; left: 0px; top: 0px; height: 150px; width: 100px; clip: rect(0px 100px 150px 0px); z-index: 2;"><TABLE><TD ID="d3_tdbox" align=center valign=center width=95 height=145 class="boxTD">Name</TD></TABLE></DIV><DIV ID="d3_img" STYLE="position: absolute; left: 0px; top: 0px; height: 150px; width: 100px; z-index: 5;"><A HREF="javascript:void(0);" NAME="d3" onMouseOver="ShowCont('d3',event)" onMouseOut="HideCont('d3',event)"><IMG NAME="d3" SRC="transp.gif" border=0 width=100 height=150></A></DIV></DIV></TD>
<!--end cell--></TR><TR><TD ID="btn_0" style="border-left-style: none; border-right-style: none; border-bottom-style: none;" align=center valign=middle><INPUT type="button" name="btn1" value="Keks 1" onMouseOver="timefunction('mouseover','btn1','Keks 1')" onClick="recChoice('onclick','btn1','Keks 1')" onMouseOut="timefunction('mouseout','btn1','Keks 1')"></TD>
<TD ID="btn_1" style="border-left-style: none; border-right-style: none; border-bottom-style: none;" align=center valign=middle><INPUT type="button" name="btn2" value="Keks 2" onMouseOver="timefunction('mouseover','btn2','Keks 2')" onClick="recChoice('onclick','btn2','Keks 2')" onMouseOut="timefunction('mouseout','btn2','Keks 2')"></TD>
<TD ID="btn_2" style="border-left-style: none; border-right-style: none; border-bottom-style: none;" align=center valign=middle><INPUT type="button" name="btn3" value="Keks 3" onMouseOver="timefunction('mouseover','btn3','Keks 3')" onClick="recChoice('onclick','btn3','Keks 3')" onMouseOut="timefunction('mouseout','btn3','Keks 3')"></TD>
<TD ID="btn_3" style="border-left-style: none; border-right-style: none; border-bottom-style: none;" align=center valign=middle><INPUT type="button" name="btn4" value="Keks 4" onMouseOver="timefunction('mouseover','btn4','Keks 4')" onClick="recChoice('onclick','btn4','Keks 4')" onMouseOut="timefunction('mouseout','btn4','Keks 4')"></TD>
</TR></TABLE>
<!-- END MOUSELAB TABLE -->
<!--BEGIN postHTML-->

<!--END postHTML--><INPUT type="submit" value="Next Page" onClick=timefunction('submit','submit','submit')></FORM></body></html>
